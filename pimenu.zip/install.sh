#/bin/sh

cd /usr/local/bin/indiecity/InstalledApps/pimenu/Full
chmod 777 ./pimenu ./pimenu.cfg ICON*

cp ./run_pimenu.sh /usr/local/games/pimenu
chmod 777 /usr/local/games/pimenu
