#/bin/sh

cd /usr/local/bin/indiecity/InstalledApps/pimenu/Full
chmod 777 ./pimenu ./pimenu.cfg ICON*
