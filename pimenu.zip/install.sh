#/bin/sh

cd /usr/local/bin/indiecity/InstalledApps/pimenu/Full
chmod 777 ./pimenu ./pimenu.cfg ICON*
ln -s /usr/local/bin/indiecity/InstalledApps/pimenu/Full/pimenu /usr/local/games/pimenu
