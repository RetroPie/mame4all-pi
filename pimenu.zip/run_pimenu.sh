cd /usr/local/bin/indiecity/InstalledApps/pimenu/Full/

exec ./pimenu
