#/bin/sh

cd /usr/local/bin/indiecity/InstalledApps/mame4all_pi/Full
chmod 777 ./samples ./artwork ./cfg ./inp ./snap ./hi ./roms ./nvram ./skins ./memcard ./frontend
